
#include <stdio.h> // Standard Input/Output library 
#include <stdlib.h> // Standard library 
#include <math.h> // Math library 
#include <string.h> // String manipulation library 

// --- Constants and Definitions ---
#define PASSWORD 8981267   // Defines the Admin password as a constant integer
#define NAME_SIZE 20       // Defines the maximum character limit for product name
#define MIN_STOCK 6        // Defines the minimum stock level 
#define MAX_STOCK 12       // Defines the maximum stock level

// --- Global Variables ---
float total_amount = 0.0;     // Stores cumulative total sales amount in AED
float price_inserted = 0.0;   // Stores and tracks the money inserted by the user for current purchase
char product_code;            // Stores a single character code ('D', 'W', 'S') for product
float current_cost = 0.0;     // Stores the current price of the item 

// Product Names (Character arrays to store product names)
char nameDoritos[NAME_SIZE] = "Doritos"; // Name of Product 1 
char nameWater[NAME_SIZE] = "Water";     // Name of Product 2 
char name7UP[NAME_SIZE] = "7UP";         // Name of Product 3

// Product Data
float costDoritos = 5.50; // Price of Product 1
float costWater = 1.50;   // Price of Product 2
float cost7UP = 3.50;     // Price of Product 3

// Quantities 
int quantityDoritos = 8; // Current stock of Product 1
int quantityWater = 9;   // Current stock of Product 2
int quantity7UP = 8;     // Current stock of Product 3


// --- Functions ---
void dis(void);                 // Function for the User Purchase (Vending Machine Display)
void admin(void);               // Function for the Admin Menu
void replenish_products(void);  // Function to restock all products
void change_price(void);        // Function to modify product price
void change_name(void);         // Function to modify product name
void disp_sales(void);          // Function to display and reset total sales number
void disp_items(void);          // Function to display current stock level


// --- Main Function ---
int main(){
    int choice; // Variable to store the user's main menu selection
    printf("--- Welcome to Vending Machine ---\n");
    
    while(1){ // Start an infinite loop for the main menu 
        // Main menu display
        printf("\n1. Purchase by User\n");
        printf("2. Admin\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        
        // User input verification: Check if a number was successfully read
        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            while (getchar() != '\n'); // Clear any remaining non-numeric input from the buffer
            continue; // Goes back to the start of the loop
        }

        if (choice == 1)
            dis(); // Calls user purchase function
        else if(choice == 2)
            admin(); // Calls admin function
        else if(choice == 3){
            printf("\nThank you for using the Vending Machine. Goodbye!\n");
            break; // Exit the infinite while loop
        } else {
            printf("Invalid option. Please choose 1, 2, or 3.\n");
        }
    }
    return 0; 
}


// --- User Purchase Function ---
void dis(void){
    int item_selection; // Variable for the user's product choice (1, 2, or 3)
    int conf;           // Variable for the purchase confirmation (0 or -1)
    
    price_inserted = 0.0; // Reset the money inserted for this new transaction
    
    // Displays the available products using the global name and price 
    printf("\n--- Available Products ---\n");
    printf("1. %s (Price: %.2f | Stock: %d)\n", nameDoritos, costDoritos, quantityDoritos);
    printf("2. %s (Price: %.2f | Stock: %d)\n", nameWater, costWater, quantityWater);
    printf("3. %s (Price: %.2f | Stock: %d)\n", name7UP, cost7UP, quantity7UP);
    printf("Enter the number of the item you want to purchase (or 0 to return): ");
    
    if (scanf("%d", &item_selection) != 1) {
        printf("Invalid input. Returning to main menu.\n");
        while (getchar() != '\n'); 
        return; // Exit function and return to main loop
    }

    // Product selection and availability check
    if (item_selection == 0) {
        return; // return to main menu
    } else if (item_selection == 1) { // Doritos (Product 1)
        if (quantityDoritos <= 0) { printf("%s is out of stock.\n", nameDoritos); return; }
        product_code = 'D';
        current_cost = costDoritos;
    } else if (item_selection == 2) { // Water (Product 2)
        if (quantityWater <= 0) { printf("%s is out of stock.\n", nameWater); return; }
        product_code = 'W';
        current_cost = costWater;
    } else if (item_selection == 3) { // 7UP (Product 3)
        if (quantity7UP <= 0) { printf("%s is out of stock.\n", name7UP); return; }
        product_code = 'S';
        current_cost = cost7UP;
    } else {
        printf("Invalid product selection. Returning to main menu.\n");
        return;
    }
    
    printf("Selected Product (Code %c). Price: %.2f\n", product_code, current_cost);

    // Confirmation step
    printf("Confirm the product by typing 0. Type -1 to return: ");
    if (scanf("%d", &conf) != 1) {
        while (getchar() != '\n');
        printf("Invalid input. Returning to main menu.\n");
        return;
    }

    if (conf == 0){ // Purchase Confirmed (0)
        printf("Product confirmed. Please insert coins.\n");
        
        while (1){ // Start the Payment loop
            float coin;
            float remaining = current_cost - price_inserted;
            if (remaining < 0) remaining = 0; // Ensure remaining amount isn't shown as negative value

            // Show current transaction status
            printf("Cost: %.2f | Inserted: %.2f | Remaining: %.2f\n", 
                   current_cost, price_inserted, remaining);
            printf("Accepted coins: 1.00, 0.50, 0.25 AED. Insert coin: ");
            
            if (scanf("%f", &coin) != 1) {
                while (getchar() != '\n');
                printf("Invalid input. Transaction cancelled and money returned.\n");
                return;
            }

            // Valid coin check (only 1.00, 0.50, 0.25 are accepted)
            if (coin == 1.00 || coin == 0.50 || coin == 0.25){
                price_inserted += coin; // Add the coin to the inserted amount

                if (price_inserted >= current_cost){ // Check if payment is complete
                    float change = price_inserted - current_cost; // Calculate the remaining change
                    
                    printf("\n*** Transaction Successful! ***\n");
                    
                    if (change > 0.0001){ // Check if change is significant in order to chech and  handle float errors
                        printf("Your change is: %.2f AED. Please collect your change and item.\n", change);
                    } else {
                        printf("Payment done. You have no change. Please collect your item.\n");
                    }
                    
                    total_amount += current_cost; // Adds the cost of the item to total sales

                    // Update stock and alert of item based on the product code
                    if (product_code == 'D'){ // Doritos
                        quantityDoritos--;
                        if (quantityDoritos <= MIN_STOCK) printf("ALERT: %s stock is low (%d).\n", nameDoritos, quantityDoritos);
                    } else if (product_code == 'W'){ // Water
                        quantityWater--;
                        if (quantityWater <= MIN_STOCK) printf("ALERT: %s stock is low (%d).\n", nameWater, quantityWater);
                    } else if(product_code == 'S'){ // 7UP
                        quantity7UP--;
                        if (quantity7UP <= MIN_STOCK) printf("ALERT: %s stock is low (%d).\n", name7UP, quantity7UP);
                    }

                    break; // Exit the payment loop
                }
            } else {
                printf("Invalid coin inserted (%.2f). Returning coin.\n", coin);
            }
        }
    }
    else if(conf == -1){ // User cancelled
        printf("Transaction cancelled. Returning to main menu.\n");
    } else { // Invalid confirmation input
        printf("Invalid confirmation. Transaction cancelled.\n");
    }
}   


// --- Admin Functions ---

void admin(void){
    int pass;     // Variable for entered password
    int adchoice; // Variable for admin menu choice
    
    printf("\nEnter Admin password: ");
    if (scanf("%d", &pass) != 1) { // Reads the password inputed
        while (getchar() != '\n');
        printf("Invalid input. Returning to main menu.\n");
        return;
    }

    if (pass != PASSWORD){
        printf("Access Denied: Invalid password.\n");
    }
    else{
        printf("\n*** Welcome to Admin Mode! ***\n");
        while (1){ // Starts admin Menu loop
            // Displays admin options 
            printf("\n--- Admin Menu ---\n");
            printf("1. Replenish Products\n");
            printf("2. Change Product Price\n");
            printf("3. Change Product Name\n");
            printf("4. Display Total Sales Amount\n");
            printf("5. Display Product Quantities\n");
            printf("0. Exit Admin Mode\n");
            printf("Enter your choice: ");
            
            if (scanf("%d", &adchoice) != 1) {
                while (getchar() != '\n');
                printf("Invalid input. Exiting Admin mode.\n");
                break;
            }

            // Route to selected admin function
            if (adchoice == 1)
                replenish_products();
            else if (adchoice == 2)
                change_price();
            else if (adchoice == 3)
                change_name();
            else if (adchoice == 4)
                disp_sales();
            else if (adchoice == 5)
                disp_items();
            else if (adchoice == 0){
                printf("You exited Admin mode.\n");
                break; // Exits admin while loop
            } else {
                printf("Invalid option. Please choose from 0-5.\n");
            }
        }
    }
}

// --- Replenish Products Function ---
void replenish_products(void){
    // Calculate the range of random numbers from MIN_STOCK to MAX_STOCK
    int range = MAX_STOCK - MIN_STOCK + 1;
    
    // Set stock for each product randomly within the allowed range [MIN_STOCK, MAX_STOCK]
    quantityDoritos = (rand() % range) + MIN_STOCK;
    quantityWater = (rand() % range) + MIN_STOCK;
    quantity7UP = (rand() % range) + MIN_STOCK;
    
    printf("Products Replenished Successfully (Max Stock: %d) to:\n", MAX_STOCK);
    disp_items(); // Show the new stock levels
}


// --- Change Product Name Function ---
void change_name(void){
    int product_num;
    printf("\n--- Change Product Name ---\n");
    printf("1. %s\n", nameDoritos);
    printf("2. %s\n", nameWater);
    printf("3. %s\n", name7UP);
    printf("Enter product number to rename (1, 2, or 3): ");
    
    if (scanf("%d", &product_num) != 1) {
        while (getchar() != '\n');
        printf("Invalid input.\n");
        return;
    }

    //Clear input buffer to prepare for reading the string name
    while (getchar() != '\n'); 
    
    // Use scanf("%s") to read a new name (string) into global character array
    if (product_num == 1){
        printf("Enter new name for %s: ", nameDoritos);
        scanf("%s", nameDoritos); // Read new name into nameDoritos array
        printf("Product 1 name successfully changed to: %s\n", nameDoritos);
    } else if (product_num == 2){
        printf("Enter new name for %s: ", nameWater);
        scanf("%s", nameWater); // Read new name into nameWater array
        printf("Product 2 name successfully changed to: %s\n", nameWater);
    } else if (product_num == 3){
        printf("Enter new name for %s: ", name7UP);
        scanf("%s", name7UP); // Read new name into name7UP array
        printf("Product 3 name successfully changed to: %s\n", name7UP);
    } else {
        printf("Invalid product number.\n");
    }
}


// --- Change Price Function ---
void change_price(void){
    printf("Enter a new price for %s (Product 1): ", nameDoritos);
    scanf("%f", &costDoritos); // Reads the new float price for Doritos
    printf("Enter a new price for %s (Product 2): ", nameWater);
    scanf("%f", &costWater);   // Reads the new float price for Water
    printf("Enter a new price for %s (Product 3): ", name7UP);
    scanf("%f", &cost7UP);     // Reads the new float price for 7UP
    printf("Products Price changed successfully.\n");
}

// --- Display Sales Function ---
void disp_sales(void){
    int reset_choice;
    printf("The total amount in sales is: %.2f AED\n", total_amount);
    printf("Do you want to reset the total amount? (1 for Yes / 0 for No): ");
    
    if (scanf("%d", &reset_choice) != 1) {
        while (getchar() != '\n');
        return;
    }

    if (reset_choice == 1){
        printf("Collected: %.2f AED. Total sales amount has been reset.\n", total_amount);
        total_amount = 0.0; // Resets the global sales counter
    }
}

// --- Display Items Function ---
void disp_items(void){
    printf("--- Current Stock Levels ---\n");
    printf("%s stock: %d\n", nameDoritos, quantityDoritos);
    printf("%s stock: %d\n", nameWater, quantityWater);
    printf("%s stock: %d\n", name7UP, quantity7UP);
}